import express from "express";

import { saveResults, getTestSet, getSavedResults, getSharedResults } from "../controllers/ReadingController.js"
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();
router.route("/").get(verifyToken, getTestSet)
router.route("/saveresult").post(verifyToken, saveResults);
router.route("/fetch-saved").post(verifyToken, getSavedResults);
router.route("/share/:shareId").get(getSharedResults);

export default router;