import Reading from "../models/ReadingModel.js";
import ReadingSaved from "../models/readingSavedModel.js";
import asyncHandler from "express-async-handler";
import { v4 as uuidv4 } from 'uuid';

const getTestSet = asyncHandler(async (req, res, next) => {
    try {
        const reading = await Reading.aggregate([{ $sample: { size: 3 } }])
        res.status(200).json({
            data: reading
          });
    } catch (e) {
      next(e);
    }
});


const saveResults = asyncHandler(async (req, res, next) => {
    const data = req.body;
    try {
        const share_id = uuidv4();
        const reading = await ReadingSaved.create({
            user_id: req.user.uid,
            passages: data.passages,
            results: data.results,
            share_id,
        });

        res.status(201).json({
            message: "saved",
            data: reading
          });
    } catch (e) {
      next(e);
    }
  });

  const getSavedResults = asyncHandler(async (req, res, next) => {
    const { data } = req.body;
    const id = data.id;
    try {
        const reading = await ReadingSaved.findOne({
          _id: id,
          user_id: req.user.uid
        });
        res.status(201).json(reading);
    } catch (e) {
      next(e);
    }    
  });

  const getSharedResults = asyncHandler(async (req, res, next) => {
    const { shareId } = req.params;
    try {
        const reading = await ReadingSaved.findOne({
          share_id: shareId,
        });
        res.status(201).json(reading);
    } catch (e) {
      next(err);
    }    
  });

export{saveResults, getTestSet, getSavedResults, getSharedResults};