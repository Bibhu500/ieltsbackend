import Speaking from "../models/speakingModel.js";
import asyncHandler from "express-async-handler";
import { v4 as uuidv4 } from 'uuid';
import jwt from "jsonwebtoken";
import User from "../models/userModel.js";

const saveResults = asyncHandler(async (req, res, next) => {
    const { data } = req.body;
    try {
        const share_id = uuidv4();
        console.log(share_id);
        console.log("Hello world")
        const speaking = await Speaking.create({
            user_id: req.user.uid,
            allQuestionsAndAnswers: data.allQuestionsAndAnswers,
            result: data.result,
            share_id,
        });
        console.log(speaking);
        res.status(201).json({
            message: "saved",
            data: speaking
          });
    } catch (e) {
      next(e);
    }
  });

  const getSavedResults = asyncHandler(async (req, res, next) => {
    const { data } = req.body;
    const id = data.id;
    try {
        console.log(id)
        const speaking = await Speaking.findOne({
          _id: id,
          user_id: req.user.uid
        });
        res.status(201).json(speaking);
    } catch (e) {
      next(e);
    }    
  });

  const getSharedResults = asyncHandler(async (req, res, next) => {
    const { shareId } = req.params;
    try {
        const speaking = await Speaking.findOne({
          share_id: shareId,
        });

        const authHeader = req.headers.authorization;  
        let isOwner = false;
        let isEditor = false;
        if(authHeader){
          const token = authHeader.split(' ')[1];
          if(token){
            try{
              const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET)
              if(decoded){
                const user_id = decoded.uid;
                if(user_id === speaking.user_id){
                  isOwner = true;
                } 
        
                if(user_id && speaking.editor_id && user_id === speaking.editor_id){
                  isEditor = true;
                } 
              }
            } catch (err){
              console.log(err.stack)
            }
          }
          
        }
        
        let editor_name;
        if(speaking.editor_id){
          const user = await User.findOne({firebaseId: speaking.editor_id});
          editor_name = user.fullName
        }

        const speakingObject = speaking.toObject();
        speakingObject.isEditor = isEditor;
        speakingObject.isOwner = isOwner;
        speakingObject.editor_name = editor_name;
        res.status(200).json(speakingObject);
    } catch (err) {
      next(err);
    }    
  });

  const addRemark = async (req, res, next) => {
    const { share_id, remarks } = req.body;
    try{
      const speaking = await Speaking.findOne({share_id});

      if(req.user.uid !== speaking.editor_id){
        return res.status(401).json({message: "you are not an editor"})
      }

      console.log(speaking)

      speaking.remarks = remarks; 
      speaking.save();
      res.json(speaking)

    } catch (err) {
      next(err);
    }
  }


export{saveResults, getSavedResults, getSharedResults, addRemark};